import { io } from 'socket.io-client';

const socket = io("http://localhost:3031");

const text = document.getElementById("desc")
const fl = document.getElementById("file")
const btn = document.getElementById("btn")
const rab = document.getElementById('pene')

btn.addEventListener('click', (e) => {
    e.preventDefault();
    socket.emit("POST", {
        caption: text.value,
        token: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjEsIm5hbWUiOiJBZG9sZm9KcnoiLCJvd25lciI6IkFkb2xmbyBKdcOhcmV6IiwiYXZhdGFyIjoiaHR0cHM6Ly9pZy1jbG9uZS1yZXNvdXJjZXMuczMuYW1hem9uYXdzLmNvbS9hdmF0YXJzLzE2Nzk5NjY0MTQxNTgtNDdhZWZkZWUzYTg3YjNmNmU4NmVhMzk0ZDg5YWM4ZGMuanBnIiwiaWF0IjoxNjc5OTY2NDU2ODk1LCJleHAiOjE2ODE2NDY0MjY5NTF9.TcKShsWMeWKEh_RgrYpvPI-RQvbhFI5RYLlaQEuP__U",
        media: fl.files[0]
    })
})

rab.addEventListener('click', (e) => {
    socket.emit("GETALL", {
        token: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjEsIm5hbWUiOiJBZG9sZm9KcnoiLCJvd25lciI6IkFkb2xmbyBKdcOhcmV6IiwiYXZhdGFyIjoiaHR0cHM6Ly9pZy1jbG9uZS1yZXNvdXJjZXMuczMuYW1hem9uYXdzLmNvbS9hdmF0YXJzLzE2Nzk5NjY0MTQxNTgtNDdhZWZkZWUzYTg3YjNmNmU4NmVhMzk0ZDg5YWM4ZGMuanBnIiwiaWF0IjoxNjc5OTY2NDU2ODk1LCJleHAiOjE2ODE2NDY0MjY5NTF9.TcKShsWMeWKEh_RgrYpvPI-RQvbhFI5RYLlaQEuP__U",
    })
})

socket.on("connect", () => {
    console.log("conectao")
})

socket.on("Log", (msg) => {
    console.log(msg)
})

socket.on("Feed", (msg) => {
    console.log(msg)
})

socket.on("POSTS",(msg)=>{
    console.log(msg)
})